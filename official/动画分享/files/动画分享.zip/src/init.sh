#!/bin/sh

export LP_NUM_THREADS=1
xvfb-run /usr/local/bin/zutty
