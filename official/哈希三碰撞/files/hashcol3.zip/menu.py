import os

if __name__ == "__main__":
    n = input('Which challenge (1 or 2): ').strip()
    if n == '1':
        os.execl('/1', '1')
    elif n == '2':
        os.execl('/2', '2')
